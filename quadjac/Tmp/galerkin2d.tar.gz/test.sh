./quadjacNew -N=20 -M=10 $1
./quadjacNew -N=40 -M=40 $1
./quadjacNew -N=80 -M=160 $1
./quadjacNew -N=160 -M=640 $1
